# city-building-mod-0-ad
This mod attempts to emulate city-building elements as in Caesar or SimCity games into 0 A.D., which emphasize building placements.
